productos = {
    'M001': ['Alimento Premium', 'comida', 'DogPlus', 10.0, True, False],
    'M002': ['Arena Aglomerante', 'higiene', 'CatClean', 8.0, False, False],
    'M003': ['Snack Dental', 'snack', 'BiteJoy', 1.0, True, True],
    'M004': ['Shampoo Suave', 'higiene', 'PetCare', 0.5, False, True],
    'M005': ['Correa Nylon', 'accesorio', 'WalkPro', 0.3, True, False],
    'M006': ['Cama Mediana', 'accesorio', 'CozyPet', 2.0, False, False]
}

stock = {
    'M001': [32990, 12],
    'M002': [9990, 0],
    'M003': [5490, 25],
    'M004': [7990, 5],
    'M005': [11990, 7],
    'M006': [24990, 3]
}

def validar_codigo(codigo):
    if not codigo or codigo.strip() == "":
        return False
    codigos_existentes = {k.upper() for k in productos.keys()}
    if codigo.strip().upper() in codigos_existentes:
        return False
    return True

def validar_nombre(nombre):
    return bool(nombre and nombre.strip() != "")

def validar_categoria(categoria):
    return bool(categoria and categoria.strip() != "")

def validar_marca(marca):
    return bool(marca and marca.strip() != "")

def validar_peso(peso_txt):
    try:
        peso = float(peso_txt)
        return peso > 0
    except ValueError:
        return False

def validar_es_importado(opcion):
    return opcion.strip().lower() in ['s', 'n']

def validar_es_para_cachorro(opcion):
    return opcion.strip().lower() in ['s', 'n']

def validar_precio(precio_txt):
    try:
        precio = int(precio_txt)
        return precio > 0
    except ValueError:
        return False

def validar_unidades(unidades_txt):
    try:
        unidades = int(unidades_txt)
        return unidades >= 0
    except ValueError:
        return False

def unidades_categoria(categoria):
    cat_buscar = categoria.strip().lower()
    total_unidades = 0
    for cod, datos in productos.items():
        if datos[1].lower() == cat_buscar:
            if cod in stock:
                total_unidades += stock[cod][1]
    print(f"El total de unidades disponibles es: {total_unidades}")

def busqueda_precio(p_min, p_max):
    resultados = []
    for cod, info_stock in stock.items():
        precio = info_stock[0]
        unidades = info_stock[1]
        if p_min <= precio <= p_max and unidades > 0:
            if cod in productos:
                nombre = productos[cod][0]
                resultados.append(f"{nombre}--{cod}")
    if resultados:
        resultados.sort()
        print(f"Los productos encontrados son: {resultados}")
    else:
        print("No hay productos en ese rango de precios.")

def actualizar_precio(codigo, nuevo_precio):
    cod_buscar = codigo.strip().upper()
    cod_real = None
    for k in stock.keys():
        if k.upper() == cod_buscar:
            cod_real = k
            break
    if cod_real is None:
        return False
    stock[cod_real][0] = nuevo_precio
    return True

def agregar_producto(codigo, nombre, categoria, marca, peso_kg, es_importado, es_para_cachorro, precio, unidades):
    cod_upper = codigo.strip().upper()
    if cod_upper in productos or cod_upper in stock:
        return False
    imp_bool = True if es_importado.strip().lower() == 's' else False
    cach_bool = True if es_para_cachorro.strip().lower() == 's' else False
    productos[cod_upper] = [nombre.strip(), categoria.strip(), marca.strip(), float(peso_kg), imp_bool, cach_bool]
    stock[cod_upper] = [int(precio), int(unidades)]
    return True

def eliminar_producto(codigo):
    cod_buscar = codigo.strip().upper()
    cod_real = None
    for k in productos.keys():
        if k.upper() == cod_buscar:
            cod_real = k
            break
    if cod_real is None:
        return False
    productos.pop(cod_real)
    stock.pop(cod_real, None)
    return True

def main():
    while True:
        print("\n========== MENÚ PRINCIPAL ==========")
        print("1. Unidades por categoría")
        print("2. Búsqueda de productos por rango de precio")
        print("3. Actualizar precio de producto")
        print("4. Agregar producto")
        print("5. Eliminar producto")
        print("6. Salir")
        print("=====================================")
        
        opcion = input("Ingrese opción: ").strip()
        
        if opcion == "1":
            cat = input("Ingrese categoría a consultar: ")
            unidades_categoria(cat)
            
        elif opcion == "2":
            while True:
                try:
                    p_min_txt = input("Ingrese precio mínimo: ")
                    p_min = int(p_min_txt)
                    p_max_txt = input("Ingrese precio máximo: ")
                    p_max = int(p_max_txt)
                    if p_min >= 0 and p_max >= 0 and p_min <= p_max:
                        busqueda_precio(p_min, p_max)
                        break
                    else:
                        print("Debe ingresar valores enteros válidos (mínimo menor o igual al máximo y mayores a cero).")
                except ValueError:
                    print("Debe ingresar valores enteros")
                    
        elif opcion == "3":
            while True:
                cod = input("Ingrese código del producto: ")
                nuevo_precio_txt = input("Ingrese nuevo precio: ")
                if validar_precio(nuevo_precio_txt):
                    nuevo_precio = int(nuevo_precio_txt)
                    exito = actualizar_precio(cod, nuevo_precio)
                    if exito:
                        print("Precio actualizado")
                    else:
                        print("El código no existe")
                else:
                    print("Debe ingresar un precio entero positivo.")
                resp = input("¿Desea actualizar otro precio (s/n)?: ").strip().lower()
                if resp != "s":
                    break
                    
        elif opcion == "4":
            cod = input("Ingrese código del producto: ")
            nombre = input("Ingrese nombre: ")
            categoria = input("Ingrese categoría: ")
            marca = input("Ingrese marca: ")
            peso_txt = input("Ingrese peso (kg): ")
            importado = input("¿Es importado? (s/n): ")
            cachorro = input("¿Es para cachorro? (s/n): ")
            precio_txt = input("Ingrese precio: ")
            unidades_txt = input("Ingrese unidades: ")
            
            errores = False
            if not validar_codigo(cod):
                print("Error: Código no puede estar vacío ni repetirse.")
                errores = True
            if not validar_nombre(nombre):
                print("Error: El nombre no puede estar vacío.")
                errores = True
            if not validar_categoria(categoria):
                print("Error: La categoría no puede estar vacía.")
                errores = True
            if not validar_marca(marca):
                print("Error: La marca no puede estar vacía.")
                errores = True
            if not validar_peso(peso_txt):
                print("Error: El peso debe ser un número decimal mayor a cero.")
                errores = True
            if not validar_es_importado(importado):
                print("Error: Debe responder 's' o 'n' para si es importado.")
                errores = True
            if not validar_es_para_cachorro(cachorro):
                print("Error: Debe responder 's' o 'n' para si es para cachorro.")
                errores = True
            if not validar_precio(precio_txt):
                print("Error: El precio debe ser un número entero mayor a cero.")
                errores = True
            if not validar_unidades(unidades_txt):
                print("Error: Las unidades deben ser un número entero mayor o igual a cero.")
                errores = True
                
            if not errores:
                agregado = agregar_producto(
                    cod, nombre, categoria, marca, float(peso_txt), 
                    importado, cachorro, int(precio_txt), int(unidades_txt)
                )
                if agregado:
                    print("Producto agregado")
                else:
                    print("El código ya existe")
            else:
                print("No se pudo registrar el producto debido a errores de validación.")
                
        elif opcion == "5":
            cod = input("Ingrese código del producto a eliminar: ")
            exito = eliminar_producto(cod)
            if exito:
                print("Producto eliminado")
            else:
                print("El código no existe")
                
        elif opcion == "6":
            print("Programa finalizado.")
            break
            
        else:
            print("Debe seleccionar una opción válida")

if __name__ == "__main__":
    main()